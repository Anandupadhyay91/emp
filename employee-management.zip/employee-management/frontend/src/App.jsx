import { useEffect, useState } from "react";
import axios from "axios";

export default function App() {
  const [employees, setEmployees] = useState([]);
  const [formData, setFormData] = useState({ name: "", age: "", phone: "", email: "" });
  const [editId, setEditId] = useState(null);

  const apiUrl = "http://localhost:5000/employees";

  // ✅ Fetch all employees
  const fetchEmployees = async () => {
    const res = await axios.get(apiUrl);
    setEmployees(res.data);
  };

  useEffect(() => { fetchEmployees(); }, []);

  // ✅ Handle input change
  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  // ✅ Add or Update employee
  const handleSubmit = async () => {
    if (editId) {
      await axios.put(`${apiUrl}/${editId}`, formData);
    } else {
      await axios.post(apiUrl, formData);
    }
    setFormData({ name: "", age: "", phone: "", email: "" });
    setEditId(null);
    fetchEmployees();
  };

  // ✅ Edit
  const handleEdit = (emp) => {
    setFormData({ name: emp.name, age: emp.age, phone: emp.phone, email: emp.email });
    setEditId(emp.id);
  };

  // ✅ Delete
  const handleDelete = async (id) => {
    await axios.delete(`${apiUrl}/${id}`);
    fetchEmployees();
  };

  return (
    <div className="container mt-5">
      <h2 className="text-center mb-4">Employee Management</h2>
      
      {/* Form */}
      <div className="card p-3 mb-4">
        <input type="text" name="name" placeholder="Name" value={formData.name} onChange={handleChange} className="form-control mb-2" />
        <input type="number" name="age" placeholder="Age" value={formData.age} onChange={handleChange} className="form-control mb-2" />
        <input type="text" name="phone" placeholder="Phone" value={formData.phone} onChange={handleChange} className="form-control mb-2" />
        <input type="email" name="email" placeholder="Email" value={formData.email} onChange={handleChange} className="form-control mb-2" />
        <button onClick={handleSubmit} className="btn btn-primary">
          {editId ? "Update Employee" : "Add Employee"}
        </button>
      </div>

      {/* Table */}
      <table className="table table-bordered">
        <thead>
          <tr>
            <th>ID</th>
            <th>Name</th>
            <th>Age</th>
            <th>Phone</th>
            <th>Email</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          {employees.map(emp => (
            <tr key={emp.id}>
              <td>{emp.id}</td>
              <td>{emp.name}</td>
              <td>{emp.age}</td>
              <td>{emp.phone}</td>
              <td>{emp.email}</td>
              <td>
                <button className="btn btn-warning btn-sm me-2" onClick={() => handleEdit(emp)}>Edit</button>
                <button className="btn btn-danger btn-sm" onClick={() => handleDelete(emp.id)}>Delete</button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
