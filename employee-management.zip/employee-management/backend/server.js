const express = require('express');
const mysql = require('mysql2');
const cors = require('cors');

const app = express();
app.use(cors());
app.use(express.json()); // to read JSON data

// ✅ Connect to MySQL
const db = mysql.createConnection({
    host: 'localhost',
    user: 'root',       // change if you have another MySQL user
    password: 'praveen',       // add your MySQL password if set
    database: 'employee_db'
});

// ✅ Test connection
db.connect(err => {
    if (err) {
        console.log("Database connection failed:", err);
        return;
    }
    console.log("Connected to MySQL Database");
});

// ✅ CREATE - Add Employee
app.post('/employees', (req, res) => {
    const { name, age, phone, email } = req.body;
    const sql = "INSERT INTO employees (name, age, phone, email) VALUES (?, ?, ?, ?)";
    db.query(sql, [name, age, phone, email], (err, result) => {
        if (err) return res.status(500).send(err);
        res.send({ message: "Employee added successfully" });
    });
});

// ✅ READ - Get All Employees
app.get('/employees', (req, res) => {
    db.query("SELECT * FROM employees", (err, results) => {
        if (err) return res.status(500).send(err);
        res.send(results);
    });
});

// ✅ UPDATE - Edit Employee
app.put('/employees/:id', (req, res) => {
    const { id } = req.params;
    const { name, age, phone, email } = req.body;
    const sql = "UPDATE employees SET name=?, age=?, phone=?, email=? WHERE id=?";
    db.query(sql, [name, age, phone, email, id], (err, result) => {
        if (err) return res.status(500).send(err);
        res.send({ message: "Employee updated successfully" });
    });
});

// ✅ DELETE - Remove Employee
app.delete('/employees/:id', (req, res) => {
    const { id } = req.params;
    db.query("DELETE FROM employees WHERE id=?", [id], (err, result) => {
        if (err) return res.status(500).send(err);
        res.send({ message: "Employee deleted successfully" });
    });
});

// ✅ Start server
const PORT = 5000;
app.listen(PORT, () => {
    console.log(`Server is running on port ${PORT}`);
});
